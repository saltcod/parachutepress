Waterstreet
===========

Waterstreet is the official starter theme for all projects at WaterstreetGM. It is an evolving fork of `_s` from Automattic. To read more about that, head on over to: http://underscores.me. 

How Can I use it? 
-----------------

You can download Waterstreet as it is, fork it, submit issues or pull requests to me to me, etc. You can do whatever you like with it. 

This is a pretty new fork, so it looks a lot like `_s` at the moment. It won't forever. I've already added a basic structure, some type defaults, and a few essential theme development functions that I use regularly. I hope to add some basic media queries and a few other essentials in the next little while. 

Stay with us!
